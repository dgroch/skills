<!-- COMPONENT: sections/body-copy-plain | BODY COPY — NO ILLUSTRATION, HTML-SAFE
TOKENS:
  How it works  — small uppercase label above headline
  More gestures, more rewards.     — Lust font — SENTENCE CASE (e.g. "The one that feels like home.")
  From 14 to 20 April, rewards points are doubled automatically at checkout: 20 points per $1 spent, normally 10.      — first paragraph
  Order for someone special, then redeem points later for free shipping, a ceramic vase, or order credit.      — second paragraph (optional — leave blank if not needed)
RULES:
  - No illustration — safe to render as inline HTML in email clients
  - Use this variant when no accent illustration is desired
  - Background is white — do not change
-->
<tr><td>
<table width="600" cellpadding="0" cellspacing="0" border="0" style="border-top:1px solid #e8e2da;">
  <tr>
    <td class="sp" align="center" style="padding:44px 64px;background:#ffffff;text-align:center;">
      <p style="font-family:'NeuzeitGro','Gill Sans','Gill Sans MT',Calibri,sans-serif;font-weight:700;font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:#aaaaaa;margin:0 0 14px 0;">How it works</p>
      <h2 class="sh" style="font-family:'Lust',Georgia,'Times New Roman',serif;font-weight:normal;font-style:normal;font-size:28px;color:#000000;line-height:1.2;margin:0 0 20px 0;">More gestures, more rewards.</h2>
      <p style="font-family:'NeuzeitGro','Gill Sans','Gill Sans MT',Calibri,sans-serif;font-weight:300;font-size:14px;color:#444444;line-height:1.85;margin:0 auto 14px auto;max-width:440px;">From 14 to 20 April, rewards points are doubled automatically at checkout: 20 points per $1 spent, normally 10.</p>
      <p style="font-family:'NeuzeitGro','Gill Sans','Gill Sans MT',Calibri,sans-serif;font-weight:300;font-size:14px;color:#444444;line-height:1.85;margin:0 auto;max-width:440px;">Order for someone special, then redeem points later for free shipping, a ceramic vase, or order credit.</p>
    </td>
  </tr>
</table>
</td></tr>
